
# ANCHAIN GLOBAL COIN MVP

Fitur:
- Deposit QRIS
- Generate kode unik 3 digit
- Deposit Solana
- Upload bukti pembayaran
- Copy wallet Solana

Cara pakai:
1. Extract file ZIP
2. Upload ke Github
3. Aktifkan Github Pages
4. Buka index.html

Struktur:
- index.html
- style.css
- script.js
- qris.jpeg
- solana.jpeg
