
function generateCode(){
  const usd = document.getElementById('usd').value;
  const rate = 16000;

  const random = Math.floor(100 + Math.random() * 900);

  const total = (usd * rate) + random;

  document.getElementById('kode').innerText = random;
  document.getElementById('rupiah').innerText =
    'Rp ' + total.toLocaleString('id-ID');
}

function copyWallet(){
  navigator.clipboard.writeText(
    'HHC1ZrK38bB2GCx29dg5VcDhzB2Yh2J5FW4T2dmT5aFR'
  );

  alert('Wallet berhasil disalin');
}
